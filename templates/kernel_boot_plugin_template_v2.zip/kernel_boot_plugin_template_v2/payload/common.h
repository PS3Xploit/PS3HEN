#ifndef KERNEL_PLUGIN_COMMON_H
#define KERNEL_PLUGIN_COMMON_H

/* Debug prints only in debug builds. */
#ifdef DEBUG
#define DPRINTF printf
#else
#define DPRINTF(...)
#endif

#endif /* KERNEL_PLUGIN_COMMON_H */
