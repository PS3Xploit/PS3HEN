#include <lv2/memory.h>
#include <lv2/io.h>
#include <lv2/error.h>
#include <lv2/libc.h>
#include <lv1/lv1.h>
#include <lv2/lv2.h>
#include <lv2/patch.h>
#include <lv2/thread.h>
#include <lv2/syscall.h>
#include <debug.h>

#include "common.h"
#include "plugin_bridge.h"

/* Stage2 debug sink callback type. */
typedef int64_t (*kernel_debug_plugin_fn_t)(const char *buffer, size_t size);

/* sys_ppu_thread_start syscall id. */
#ifndef SYS_PPU_THREAD_START
#define SYS_PPU_THREAD_START 53
#endif

/* _sys_process_spawn syscall id. */
#ifndef SYS_PROCESS_SPAWN
#define SYS_PROCESS_SPAWN 21
#endif

/* Return a sink only when the plugin explicitly requests one. */
#define KERNEL_PLUGIN_ENABLE_DEBUG_SINK 0

/* Sample value exposed through the bridge syscall. */
static uint64_t g_bridge_value = 0;

/* Sample buffer returned by the replacement console id syscall. */
static const uint8_t g_sample_console_id[16] = { 0 };

/* Native syscall prototypes used by the sample hooks. */
typedef int32_t (*sys_process_getpid_fn_t)(void);
typedef int32_t (*sys_ppu_thread_start_fn_t)(uint64_t thread_id);
typedef int32_t (*sys_process_spawn_fn_t)(int32_t *pid, int32_t prio, uint64_t flags, void *stack, int32_t stack_size, int32_t unk1, int32_t unk2);

/* Saved native syscall entries. */
static sys_process_getpid_fn_t real_sys_process_getpid = NULL;
static sys_ppu_thread_start_fn_t real_sys_ppu_thread_start = NULL;
static sys_process_spawn_fn_t real_sys_process_spawn = NULL;

/*
 * Minimal custom syscall bridge.
 *
 * This gives user plugins a simple kernel entry point without extra framework
 * code.
 */
LV2_SYSCALL2(uint64_t, sys_kernel_plugin_bridge, (uint64_t command, uint64_t value))
{
    switch (command)
    {
        case KERNEL_PLUGIN_BRIDGE_CMD_PING:
            return KERNEL_PLUGIN_BRIDGE_MAGIC;

        case KERNEL_PLUGIN_BRIDGE_CMD_GET_VERSION:
            return KERNEL_PLUGIN_BRIDGE_VERSION;

        case KERNEL_PLUGIN_BRIDGE_CMD_GET_VALUE:
            return g_bridge_value;

        case KERNEL_PLUGIN_BRIDGE_CMD_SET_VALUE:
            g_bridge_value = value;
            return g_bridge_value;

        default:
            return (uint64_t)-1;
    }
}

/* Hook sys_process_getpid and forward to the native syscall. */
LV2_SYSCALL2(int32_t, syscall_hook_process_getpid, (void))
{
    DPRINTF("[kbt] sys_process_getpid()\n");

    if (!real_sys_process_getpid)
        return -1;

    return real_sys_process_getpid();
}

/* Hook sys_ppu_thread_start and forward to the native syscall. */
LV2_SYSCALL2(int32_t, syscall_hook_ppu_thread_start, (uint64_t thread_id))
{
    DPRINTF("[kbt] sys_ppu_thread_start(thread=0x%llX)\n",
        (unsigned long long)thread_id);

    if (!real_sys_ppu_thread_start)
        return -1;

    return real_sys_ppu_thread_start(thread_id);
}

/* Hook _sys_process_spawn and forward to the native syscall. */
LV2_SYSCALL2(int32_t, syscall_hook_process_spawn, (int32_t *pid, int32_t prio, uint64_t flags, void *stack, int32_t stack_size, int32_t unk1, int32_t unk2))
{
    DPRINTF("[kbt] _sys_process_spawn(prio=%d flags=0x%llX stack=0x%llX size=0x%X)\n",
        prio,
        (unsigned long long)flags,
        (unsigned long long)stack,
        (unsigned int)stack_size);

    if (!real_sys_process_spawn)
        return ENOSYS;

    return real_sys_process_spawn(pid, prio, flags, stack, stack_size, unk1, unk2);
}

/*
 * Sample replacement for a removed firmware syscall.
 *
 * Replace the sample buffer copy with real console id logic when needed.
 */
LV2_SYSCALL2(int32_t, sys_ss_get_console_id, (void *console_id))
{
    DPRINTF("[kbt] sys_ss_get_console_id(buf=0x%llX)\n",
        (unsigned long long)console_id);

    if (!console_id)
        return EFAULT;

    memcpy(console_id, g_sample_console_id, sizeof(g_sample_console_id));
    return 0;
}

/* Install the sample bridge syscall. */
static void install_bridge_syscall(void)
{
    create_syscall2(KERNEL_PLUGIN_BRIDGE_SC, sys_kernel_plugin_bridge);
}

/* Install sample native syscall hooks. */
static void install_syscall_hooks(void)
{
    uint64_t **table = (uint64_t **)MKA(syscall_table_symbol);

    real_sys_process_getpid = (sys_process_getpid_fn_t)table[SYS_PROCESS_GETPID];
    real_sys_ppu_thread_start = (sys_ppu_thread_start_fn_t)table[SYS_PPU_THREAD_START];
    real_sys_process_spawn = (sys_process_spawn_fn_t)table[SYS_PROCESS_SPAWN];

    create_syscall2(SYS_PROCESS_GETPID, syscall_hook_process_getpid);
    create_syscall2(SYS_PPU_THREAD_START, syscall_hook_ppu_thread_start);
    create_syscall2(SYS_PROCESS_SPAWN, syscall_hook_process_spawn);
}

/* Install sample replacements for removed firmware syscalls. */
static void install_missing_syscalls(void)
{
    create_syscall2(SYS_SS_GET_CONSOLE_ID_SC, sys_ss_get_console_id);
}

#if KERNEL_PLUGIN_ENABLE_DEBUG_SINK
/* Optional stage2 debug sink. */
static int64_t kernel_plugin_debug_sink(const char *buffer, size_t size)
{
    (void)buffer;
    (void)size;
    return 0;
}
#endif

/* Kernel payload entry point. */
kernel_debug_plugin_fn_t main(void)
{
    install_bridge_syscall();
    install_syscall_hooks();
    install_missing_syscalls();

    DPRINTF("[kbt] Hello World!\n");
    DPRINTF("[kbt] ready: bridge sc=%d value=0x%llX\n",
        KERNEL_PLUGIN_BRIDGE_SC,
        (unsigned long long)g_bridge_value);

#if KERNEL_PLUGIN_ENABLE_DEBUG_SINK
    return kernel_plugin_debug_sink;
#else
    return NULL;
#endif
}
