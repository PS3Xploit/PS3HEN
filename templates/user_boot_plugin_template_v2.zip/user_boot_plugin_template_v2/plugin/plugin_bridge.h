#ifndef PLUGIN_BRIDGE_H
#define PLUGIN_BRIDGE_H

/* Sample replacement slot for removed firmware syscalls. */
#define SYS_SS_GET_CONSOLE_ID_SC      1021

/* Custom syscall used by the sample kernel <-> user bridge. */
#define KERNEL_PLUGIN_BRIDGE_SC       1022

/* Bridge identity returned by the ping command. */
#define KERNEL_PLUGIN_BRIDGE_MAGIC    0x4B425244ULL /* 'KBRD' */

/* Bridge version 1.0. */
#define KERNEL_PLUGIN_BRIDGE_VERSION  0x00010000U

/* Minimal bridge commands. */
enum
{
    KERNEL_PLUGIN_BRIDGE_CMD_PING = 0,
    KERNEL_PLUGIN_BRIDGE_CMD_GET_VERSION,
    KERNEL_PLUGIN_BRIDGE_CMD_GET_VALUE,
    KERNEL_PLUGIN_BRIDGE_CMD_SET_VALUE,
};

#endif /* PLUGIN_BRIDGE_H */
