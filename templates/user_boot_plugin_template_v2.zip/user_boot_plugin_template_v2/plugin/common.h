#ifndef __COMMON_H__
#define __COMMON_H__

/* Debug prints only in debug builds. */
#ifdef DEBUG
#define DPRINTF printf
#else
#define DPRINTF(...)
#endif

#endif /* __COMMON_H__ */
