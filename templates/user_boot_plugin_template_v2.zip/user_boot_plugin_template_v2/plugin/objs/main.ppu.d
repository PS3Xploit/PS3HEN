objs/main.ppu.o: main.c common.h stdc.h plugin_bridge.h
