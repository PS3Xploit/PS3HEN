#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>

#include <sys/prx.h>
#include <sys/ppu_thread.h>
#include <sys/syscall.h>
#include <sys/timer.h>

#include "common.h"
#include "stdc.h"
#include "plugin_bridge.h"

SYS_MODULE_INFO(user_boot_plugin_template, 0, 1, 0);
SYS_MODULE_START(user_boot_plugin_template_start);
SYS_MODULE_STOP(user_boot_plugin_template_stop);
SYS_MODULE_EXIT(user_boot_plugin_template_stop);

#define THREAD_NAME      "user_boot_plugin_template_thread"
#define STOP_THREAD_NAME "user_boot_plugin_template_stop_thread"

static sys_ppu_thread_t thread_id = (sys_ppu_thread_t)-1;
static int (*vshtask_notify)(int, const char *) = NULL;

int user_boot_plugin_template_start(uint64_t arg);
int user_boot_plugin_template_stop(void);

/* Resolve an exported VSH function by module name and FNID. */
static void *getNIDfunc(const char *vsh_module, uint32_t fnid, int offset)
{
    /* 0x10000 = ELF, 0x10080 = segment 2 start, 0x10200 = code start. */
    uint32_t table = (*(uint32_t *)0x1008C) + 0x984;

    while (((uint32_t)*(uint32_t *)table) != 0)
    {
        uint32_t *export_stru_ptr = (uint32_t *)*(uint32_t *)table;
        const char *lib_name_ptr = (const char *)*(uint32_t *)((char *)export_stru_ptr + 0x10);

        if (strncmp(vsh_module, lib_name_ptr, strlen(lib_name_ptr)) == 0)
        {
            uint32_t lib_fnid_ptr = *(uint32_t *)((char *)export_stru_ptr + 0x14);
            uint32_t lib_func_ptr = *(uint32_t *)((char *)export_stru_ptr + 0x18);
            uint16_t count = *(uint16_t *)((char *)export_stru_ptr + 6);
            int i;

            for (i = 0; i < count; i++)
            {
                if (fnid == *(uint32_t *)((char *)lib_fnid_ptr + i * 4))
                {
                    return (void **)*((uint32_t *)(lib_func_ptr) + i) + offset;
                }
            }
        }

        table += 4;
    }

    return 0;
}

/* Display a short XMB notification. */
static void show_msg(const char *msg)
{
    char text[201];
    size_t len;

    if (!vshtask_notify)
        vshtask_notify = getNIDfunc("vshtask", 0xA02D46E7, 0);

    if (!vshtask_notify)
        return;

    len = strlen(msg);
    if (len > 200)
        len = 200;

    memcpy(text, msg, len);
    text[len] = '\0';
    vshtask_notify(0, text);
}

/* Call the sample kernel bridge syscall. */
static inline uint64_t bridge_call(uint64_t command, uint64_t value)
{
    system_call_2(KERNEL_PLUGIN_BRIDGE_SC, command, value);
    return_to_user_prog(uint64_t);
}

/* Exit the current PPU thread through the raw syscall. */
static inline void _sys_ppu_thread_exit(uint64_t val)
{
    system_call_1(41, val);
}

/* Resolve the current PRX id from an address inside the module. */
static inline sys_prx_id_t prx_get_module_id_by_address(void *addr)
{
    system_call_1(461, (uint64_t)(uint32_t)addr);
    return (int)p1;
}

/* Stop the current PRX module. */
static void stop_prx_module(void)
{
    sys_prx_id_t prx = prx_get_module_id_by_address(stop_prx_module);
    int *result = NULL;
    uint64_t meminfo[5];

    meminfo[0] = 0x28;
    meminfo[1] = 2;
    meminfo[2] = 0;
    meminfo[3] = 0;
    meminfo[4] = 0;

    system_call_6(482, (uint64_t)prx, 0, (uint64_t)(uint32_t)meminfo, (uint64_t)(uint32_t)result, 0, NULL);
}

/* Worker thread started by the PRX entry point. */
static void user_boot_plugin_template_thread(__attribute__((unused)) uint64_t arg)
{
    uint64_t magic;
    uint64_t version;
    uint64_t value;

    DPRINTF("[ubt] Hello World!\n");
    show_msg("Hello World!");

    magic = bridge_call(KERNEL_PLUGIN_BRIDGE_CMD_PING, 0);
    if (magic != KERNEL_PLUGIN_BRIDGE_MAGIC)
    {
        DPRINTF("[ubt] kernel bridge not ready\n");
        sys_ppu_thread_exit(0);
    }

    bridge_call(KERNEL_PLUGIN_BRIDGE_CMD_SET_VALUE, 1);
    version = bridge_call(KERNEL_PLUGIN_BRIDGE_CMD_GET_VERSION, 0);
    value = bridge_call(KERNEL_PLUGIN_BRIDGE_CMD_GET_VALUE, 0);

    DPRINTF("[ubt] bridge ready: ver=0x%08X val=%llu\n",
        (unsigned int)version,
        (unsigned long long)value);

    sys_ppu_thread_exit(0);
}

int user_boot_plugin_template_start(__attribute__((unused)) uint64_t arg)
{
    sys_ppu_thread_create(&thread_id,
        user_boot_plugin_template_thread,
        0,
        3000,
        0x4000,
        SYS_PPU_THREAD_CREATE_JOINABLE,
        THREAD_NAME);

    _sys_ppu_thread_exit(0);
    return SYS_PRX_RESIDENT;
}

/* Wait for the worker thread before stopping the PRX. */
static void user_boot_plugin_template_stop_thread(__attribute__((unused)) uint64_t arg)
{
    uint64_t exit_code;

    if (thread_id != (sys_ppu_thread_t)-1)
        sys_ppu_thread_join(thread_id, &exit_code);

    sys_ppu_thread_exit(0);
}

int user_boot_plugin_template_stop(void)
{
    sys_ppu_thread_t t_id;
    uint64_t exit_code;
    int ret;

    ret = sys_ppu_thread_create(&t_id,
        user_boot_plugin_template_stop_thread,
        0,
        3000,
        0x2000,
        SYS_PPU_THREAD_CREATE_JOINABLE,
        STOP_THREAD_NAME);

    if (ret == 0)
        sys_ppu_thread_join(t_id, &exit_code);

    sys_timer_usleep(7000);
    stop_prx_module();
    _sys_ppu_thread_exit(0);

    return SYS_PRX_STOP_OK;
}
