@echo off
del plugin.sprx
scetool --template=data\plugin_template.sprx --verbose --sce-type=SELF --compress-data=TRUE --encrypt plugin.prx plugin.sprx 
scetool --template=data\plugin_template.sprx --verbose --sce-type=SELF --compress-data=TRUE --encrypt plugin_DEBUG.prx plugin_DEBUG.sprx 

echo.
echo Done!
echo.
pause


